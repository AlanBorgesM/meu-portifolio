import requests
EXCHANGE_URL = 'https://api.exchangerate.host/latest'
def cotacao_dolar_para_brl() -> dict:
    params = {'base': 'USD', 'symbols': 'BRL'}
    r = requests.get(EXCHANGE_URL, params=params, timeout=6)
    r.raise_for_status()
    data = r.json()
    return {'base': data.get('base'), 'date': data.get('date'), 'rate': data['rates']['BRL']}
