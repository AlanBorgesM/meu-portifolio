def fatorial(n: int) -> int:
    if n < 0:
        raise ValueError('n deve ser >= 0')
    if n <= 1:
        return 1
    return n * fatorial(n - 1)

def busca_binaria_rec(arr, target, left=0, right=None):
    if right is None:
        right = len(arr) - 1
    if left > right:
        return -1
    mid = (left + right) // 2
    if arr[mid] == target:
        return mid
    elif arr[mid] < target:
        return busca_binaria_rec(arr, target, mid+1, right)
    else:
        return busca_binaria_rec(arr, target, left, mid-1)
