# Portfólio - Projeto de Algoritmos e Programação (Simples)

Este repositório contém um projeto simples em Streamlit que demonstra os conceitos pedidos pela disciplina:

- Decisão e Repetição
- Vetores e Matrizes (NumPy)
- Funções e Bibliotecas
- Registros e arquivos em disco (JSON)
- Recursividade
- Análise de complexidade (Big O)
- Uso de APIs externas (ViaCEP e exchangerate.host)

## Como rodar localmente

1. Crie e ative um ambiente virtual (recomendado):

```bash
python -m venv .venv
# Linux / macOS
source .venv/bin/activate
# Windows (PowerShell)
.venv\Scripts\Activate.ps1
```

2. Instale dependências:

```bash
pip install -r requirements.txt
```

3. Rode o app:

```bash
streamlit run app.py
```

## Observações
- O app tem interface simples adequada para apresentação.
- O bot do Telegram NÃO está incluído nesta versão (opcional).
- Arquivo `vehicles.json` é criado automaticamente quando necessário.
