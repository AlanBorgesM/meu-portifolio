def soma_lista(lst):
    s = 0
    for x in lst:
        s += x
    return s

def encontra_maior(lst):
    if not lst:
        return None
    maior = lst[0]
    for x in lst:
        if x > maior:
            maior = x
    return maior
