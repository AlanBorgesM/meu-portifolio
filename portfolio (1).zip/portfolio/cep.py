import requests
VIACEP_URL = 'https://viacep.com.br/ws/{cep}/json/'
def consulta_cep(cep: str) -> dict:
    cep = ''.join(filter(str.isdigit, str(cep)))
    if len(cep) != 8:
        raise ValueError('CEP deve ter 8 dígitos')
    url = VIACEP_URL.format(cep=cep)
    r = requests.get(url, timeout=6)
    r.raise_for_status()
    data = r.json()
    if data.get('erro'):
        raise ValueError('CEP não encontrado')
    return data
