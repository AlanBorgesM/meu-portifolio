import streamlit as st
from cep import consulta_cep
from dolar import cotacao_dolar_para_brl
from fleet import gerar_veiculos_exemplo, atualizar_posicoes_simuladas, get_fleet_status
from matrix_ops import exemplo_operacoes
from recursion import fatorial

from streamlit_folium import st_folium
import folium

st.set_page_config(page_title='Portfólio - Algoritmos', layout='wide')
st.title('Portfólio — Projeto de Algoritmos e Programação (Simples)')

st.sidebar.header('Ferramentas')
choice = st.sidebar.selectbox('Escolha', ['Home', 'Consulta CEP', 'Cotação Dólar', 'Frota', 'Matrizes & Recursão', 'Complexidade'])

if choice == 'Home':
    st.write('Este portfólio demonstra os conceitos da disciplina: decisões, repetições, vetores, matrizes, recursão, arquivos, APIs e complexidade.')

if choice == 'Consulta CEP':
    cep = st.text_input('Digite o CEP (apenas números)')
    if st.button('Consultar CEP'):
        try:
            data = consulta_cep(cep)
            st.json(data)
        except Exception as e:
            st.error(str(e))

if choice == 'Cotação Dólar':
    if st.button('Consultar USD -> BRL'):
        try:
            c = cotacao_dolar_para_brl()
            st.write(f"Base: {c['base']} — Data: {c['date']}")
            st.metric(label='USD → BRL', value=f"{c['rate']:.4f}")
        except Exception as e:
            st.error(str(e))

if choice == 'Frota':
    st.header('Monitoramento de frota (simulado)')
    if st.button('Gerar veículos de exemplo'):
        gerar_veiculos_exemplo(6)
        st.success('Veículos gerados (vehicles.json)')
    if st.button('Atualizar posições (simular)'):
        atualizar_posicoes_simuladas()
        st.success('Posições atualizadas')

    fleet = get_fleet_status()
    st.write(f'Veículos: {len(fleet)}')
    if fleet:
        m = folium.Map(location=[fleet[0]['lat'], fleet[0]['lon']], zoom_start=12)
        for v in fleet:
            folium.Marker([v['lat'], v['lon']], popup=f"{v['plate']} - {v['status']}").add_to(m)
        st_folium(m, width=700)

if choice == 'Matrizes & Recursão':
    st.header('Vetores, Matrizes e Recursão')
    ops = exemplo_operacoes()
    st.json(ops)
    n = st.number_input('Fatorial, n:', min_value=0, value=5)
    if st.button('Calcular fatorial'):
        st.write(fatorial(int(n)))

if choice == 'Complexidade':
    st.header('Análise de Complexidade (Big O)')
    st.markdown('''
    - Busca linear: O(n)
    - Busca binária: O(log n)
    - Fatorial (recursivo): O(n)
    - Atualização de posições da frota (N veículos): O(N)
    - Operações vetoriais com NumPy são muito mais rápidas que Python puro.
    ''')
