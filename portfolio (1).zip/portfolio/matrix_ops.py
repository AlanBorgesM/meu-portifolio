import numpy as np
def exemplo_operacoes():
    v = np.array([1,2,3,4])
    m = np.array([[1,2],[3,4]])
    soma_v = v + 10
    mat_prod = m @ m
    transposta = m.T
    soma_manual = 0
    for x in v:
        soma_manual += int(x)
    return {'v': v.tolist(), 'm': m.tolist(), 'soma_v': soma_v.tolist(), 'mat_prod': mat_prod.tolist(), 'transposta': transposta.tolist(), 'soma_manual': soma_manual}
