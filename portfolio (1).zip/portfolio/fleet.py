import random, os, json
from typing import List, Dict
DATA_PATH = os.path.join(os.path.dirname(__file__), '..', 'vehicles.json')
def _ensure():
    if not os.path.exists(DATA_PATH):
        gerar_veiculos_exemplo(5)
def gerar_veiculos_exemplo(n=5):
    vehicles = []
    for i in range(1, n+1):
        vehicles.append({'id': i, 'plate': f'ABC{i:03d}', 'lat': -23.55 + random.uniform(-0.05,0.05), 'lon': -46.63 + random.uniform(-0.05,0.05), 'status': random.choice(['on_route','idle','maintenance'])})
    with open(DATA_PATH, 'w', encoding='utf-8') as f:
        json.dump(vehicles, f, ensure_ascii=False, indent=2)
    return vehicles
def atualizar_posicoes_simuladas():
    _ensure()
    with open(DATA_PATH, 'r', encoding='utf-8') as f:
        vehicles = json.load(f)
    for v in vehicles:
        v['lat'] += random.uniform(-0.001, 0.001)
        v['lon'] += random.uniform(-0.001, 0.001)
        if random.random() < 0.05:
            v['status'] = 'maintenance'
    with open(DATA_PATH, 'w', encoding='utf-8') as f:
        json.dump(vehicles, f, ensure_ascii=False, indent=2)
    return vehicles
def get_fleet_status() -> List[Dict]:
    _ensure()
    with open(DATA_PATH, 'r', encoding='utf-8') as f:
        return json.load(f)
