def monitorar(): pass
