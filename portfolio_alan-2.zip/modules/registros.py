class Registro: pass
