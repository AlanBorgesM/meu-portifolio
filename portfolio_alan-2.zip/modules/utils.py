def carregar_arquivo(path): pass
