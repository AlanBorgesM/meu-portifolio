def cotacao_dolar(): pass
