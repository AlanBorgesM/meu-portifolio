def consulta_cep(cep): pass
